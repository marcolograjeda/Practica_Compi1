/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Junior
 */
public class Dato {
    public String cadena;
    public int num;
    public double decimal;
    public int tipo;
    public Dato(int tipo, String cadena, int num, double decimal) {
        this.cadena = cadena;
        this.num = num;
        this.decimal = decimal;
        this.tipo = tipo;
    }
    
    
}
